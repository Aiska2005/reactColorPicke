import React from "react";
import { TwitterPicker } from "react-color";

const TwitterCOlor = ({ setBlockTwitterColor, blockTwitterColor }) => {
  return (
    <div>
      <TwitterPicker
        color={blockTwitterColor}
        onChange={(color) => {
          setBlockTwitterColor(color.hex);
        }}
      />
    </div>
  );
};

export default TwitterCOlor;
