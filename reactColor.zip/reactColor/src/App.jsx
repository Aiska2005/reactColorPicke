import { useState } from "react";
import "./App.css";
import TwitterCOlor from "./components/blockTwitterColor/TwitterCOlor";
import { PhotoshopPicker } from "react-color";

function App() {
  const [currentColor, setCurrentColor] = useState("#ff6");
  const [blockTwitterColor, setBlockTwitterColor] = useState("#37d67a");
  const handleOnChange = (color) => {
    setCurrentColor(color.hex);
  };
  const appStyle = {
    backgroundColor: currentColor,
    height: "50vh",
    display: "flex",
    paddingLeft: 400,
    color: "#fff",
  };
  return (
    <div className="App">
      <div className="blockColor">
        <h1 style={appStyle}>React Color Picker</h1>
      </div>

      <div className="picker">
        <PhotoshopPicker
          styles={{ width: "100px", width: "1000px" }}
          color={currentColor}
          onChangeComplete={handleOnChange}
        />
        <h2 className="resultColor"> Here's your color code {currentColor}</h2>
        <div
          className="block_col"
          style={{ background: `${blockTwitterColor}`, marginLefr: "100px" }}
        >
          <TwitterCOlor
            blockTwitterColor={blockTwitterColor}
            setBlockTwitterColor={setBlockTwitterColor}
          />
        </div>
      </div>
    </div>
  );
}

export default App;
